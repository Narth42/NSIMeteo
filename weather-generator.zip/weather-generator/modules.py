# Ce fichier fait partie du projet "NSImétéo" et est distribué sous la licence GPL v3+.
# Veuillez consulter le fichier LICENSE pour plus d'informations sur la licence.
# Le projet "NSImétéo" est aussi distribué sous la licence Creative Commons Attribution-ShareAlike (CC BY-SA).
# Pour plus d'informations sur cette licence, veuillez consulter le lien suivant : https://creativecommons.org/licenses/by-sa/4.0/.

from turtle import *
from random import *
import math
import datetime
import requests

# Obtention de la météo à partir d'une clé API qui nous donne les informations sur la météo d'une ville en particulier

#Mêttre l'api de la météo
API_KEY = ""
ville = input("Veuillez entrer le nom de la ville dont vous voulez connaître la météo : ")
url = "https://api.openweathermap.org/data/2.5/weather?q=" + ville + "&lang=fr&units=metric&appid=" + API_KEY
r = requests.get(url)
data = r.json()
assert data["cod"] == 200, "La ville entrée n'existe pas"
print(data)

# à chaque type de ciel est associé un dégradé de couleur
pinkSky = ["#ffd9df", "#f6d8df", "#eed8e0", "#e6d8e1", "#ded8e1", "#d6d8e2", "#cdd8e3"]
setDay = ["#9AB0D3", "#A7B6C4", "#B9BFAE", "#C8C59D", "#D9CB84", "#EDC565", "#FAAF4A"]
nightSky = ["#000103", "#05050F", "#090B1C", "#0C102B", "#13183E", "#1A1F52", "#1E2B60"]
daySky = ["#0276BA", "#0085C4", "#0091CC", "#0C9DD3", "#33A8D9", "#4CB1DD", "#6ABDE4"]
WinterDaySky = ["#34597A", "#3C6182", "#456D8F", "#557D9E", "#6186A6", "#7496B0", "#6E95B4"]
sunsetSky = ["#D57C4E", "#DB6645", "#FF6F41", "#FE7B3D", "#FF8741", "#FE983F", "#FE9E2A"]
rainySky = ["#202020", "#404040", "#606060", "#808080", "#a0a0a0", "#c0c0c0", "#e0e0e0"]

# Obtention des données de l'heure et la date actuelle
ajd = str(datetime.datetime.now())


def separation_temps(string):
    assert string != "", "La chaîne de caractères prise en paramètre est vide"
    a = string[0]
    L = []
    for i in string[1:]:
        if i == "-" or i == ":" or i == "." or i == " ":
            L.append(int(a))
            a = ""
        else:
            a += i
    return L


ajd_liste = separation_temps(ajd)


def temps_dict(liste):
    dico = {"annee": liste[0], "mois": liste[1], "jour": liste[2], "heure": liste[3], "minute": liste[4],
            "seconde": liste[5]}
    return dico


ajd_dico = temps_dict(ajd_liste)

sunset_unix = data["sys"]["sunset"]
sunset_datetime = datetime.datetime.fromtimestamp(sunset_unix)
sunset_local = sunset_datetime + datetime.timedelta(seconds=7200)
sunset_heure = sunset_local.strftime("%H:%M:%S")
sunset_hour = int(sunset_heure[0:2]) - 1
sunrise_unix = data["sys"]["sunrise"]
sunrise_datetime = datetime.datetime.fromtimestamp(sunrise_unix)
sunrise_local = sunrise_datetime + datetime.timedelta(seconds=7200)
sunrise_heure = sunrise_local.strftime("%H:%M:%S")
sunrise_hour = int(sunrise_heure[0:2]) - 1


######################


def getSeason():
    season = ajd_dico["mois"] // 3
    return season


def getMonth():
    '''
    Un certain nombre de mois sont associés à une saison
    '''
    return ajd_dico["mois"] - 1


def getHour():
    '''
    Obtient l'heure actuelle en temps réel
    '''
    return ajd_dico["heure"] - 1


def getMinute():
    '''
    Obtient l'heure et la minute actuelle en temps réel
    '''
    return ajd_dico["minute"] - 1


def partDay(hour, season):
    '''
    fonction qui associe les données sélectionnées à partir de la graine aux différentes palettes de couleurs
    '''

    if sunrise_hour < hour < sunset_hour:
        if season == 0:
            return WinterDaySky  # si la saison sélectionnée est l'hiver, afficher le ciel d'hiver de jour
        else:
            return daySky  # sinon afficher le ciel de jour classique
    elif hour < sunrise_hour or hour > sunset_hour:
        return nightSky  # si l'heure sélectionnée est entre 18h et 6h, afficher le ciel de nuit
    else:
        return sunsetSky  # affiche dans le ciel le coucher de soleil


def fullRectangle(widht, height):
    '''
    Permet de dessiner un rectangle, utile pour plus tard dans la création ciel et routes notamment
    '''

    begin_fill()
    setheading(0)
    for loop in range(2):
        forward(widht)
        right(90)
        forward(height)
        right(90)

    end_fill()


def createSky(skyColors):
    '''
    Affiche en premier lieu le fond et le ciel grâce au fonction créer au préalable
    '''

    y = 544

    for i in range(7):
        setpos((-1022, y))
        setheading(90)
        fillcolor(skyColors[i])
        fullRectangle(2044, 100)
        y -= 100

    if skyColors == nightSky:
        for i in range(900):
            generateStar()


def createSun(hour, minute, season):
    '''
    Affiche la position du soleil en fonction de l'heure donnée
    '''

    yposition = [360, 200, 160, 120, 80, 40, 0, 60, 120, 180, 240, 300, 360, 200, 160, 120, 80, 40, 0,
                 60, 120, 180, 240, 300]
    xPosition = [0, 90, 180, 270, 360, 450, -540, -450, -360, -270, -180, -90, 0, 90, 180, 270, 360, 450,
                 540, -450, -360, -270, -180, -90]

    if sunrise_hour < hour < sunset_hour:
        if season == 0:
            fillcolor("#EBF1F7")  # la couleure diffère également si la saison sélectionné est l'hivers
        else:
            fillcolor("yellow")  # la couleur du soleil entre le levé de soleil et le couché de soleil

    elif hour < sunrise_hour or hour > sunset_hour:  # le soleil devient blanc (la lune) entre le couché de soleil et le levé de soleil
        fillcolor("white")
    else:
        fillcolor(
            "orange")  # la couleur du soleil pendant toute les autres possibilité, c'est-à-dire uniquement le coucher de soleil

    setpos(xPosition[hour] + minute, yposition[hour])
    begin_fill()
    circle(50)
    end_fill()


def generateStar():
    '''
    création des étoiles dans le ciel
    '''
    penup()
    color("white")
    x = randint(-1022, 1022)
    y = randint(-200, 544)
    dot_size = random() * 3  # avec 3 tailles aléatoires
    goto(x, y)
    dot(dot_size)
    color("black")


# Couleurs aléatoires:

def couleur():
    '''
    Cette fonction renvoie une couleur RVB aléatoire.
    :return: (tuple)
    '''
    colormode(255)
    couleur = (randint(0, 255), randint(0, 255), randint(0, 255))
    return couleur


# Sol:

def sol(y_sol):
    '''
    Cette fonction dessine une droite qui définit le sol de la rue.
    :param y_sol: (float) un nombre réel.
    '''
    width(3)
    up()
    goto(-1022, y_sol)
    down()
    forward(2044)
    width(1)


def trottoir(y_sol):
    '''
    Cette fonction dessine une droite qui définit le trottoir.
    :param y_sol: (float) un nombre réel.
    '''
    up()
    goto(-1022, y_sol)
    down()
    forward(2044)
    width(1)


# Porte rectangulaire:

def porte1(x, y, l, h):
    '''
    Cette fonction dessine une porte rectangulaire.
    :param x: (float) un nombre réel.
    :param y: (float) un nombre réel.
    :param l: (float) un nombre réel.
    :param h: (float) un nombre réel.
    '''
    up()
    goto(x, y)
    down()
    fillcolor(couleur())
    begin_fill()
    for i in range(2):
        forward(l)
        left(90)
        forward(h)
        left(90)
    end_fill()
    up()


# Porte avec un demi-cercle:

def porte2(x, y, l, h):
    '''
    Cette fonction dessine une porte avec un demi-cercle.
    :param x: (float) un nombre réel.
    :param y: (float) un nombre réel.
    :param l: (float) un nombre réel.
    :param h: (float) un nombre réel.
    '''

    up()
    goto(x, y)
    down()
    fillcolor(couleur())
    begin_fill()
    forward(l)
    left(90)
    forward(h)
    circle(15, 180)
    forward(h)
    left(90)
    end_fill()
    up()


# Portes aléatoires:

def porte(x, y):
    '''
    Cette fonction génère une porte aléatoire de largeur 30 px.
    :param x: (float) un nombre réel.
    :param y: (float) un nombre réel.
    '''
    a = randint(0, 1)
    if a == 0:
        porte1(x, y, 30, 50)
    else:
        porte2(x, y, 30, 35)


# Fenêtres:

def fenetre(x, y, skyColors):
    '''
    Cette fonction dessine une fenêtre carré de côté 30 px.
    :param x: (float) un nombre réel.
    :param y: (float) un nombre réel.
    '''
    up()
    goto(x, y)
    down()
    if skyColors == nightSky:
        colors = choice(["#f7cb05", "#000929", "#000929", "#000929", "#000929"])
        fillcolor(colors)
    else:
        fillcolor("#5baaf0")
    begin_fill()
    forward(30)
    left(90)
    forward(30)
    left(90)
    forward(30)
    left(90)
    forward(30)
    left(90)
    end_fill()
    up()


# Porte-fenêtres avec balcon:

def porte_fenetre(x, y, skyColors):
    '''
    Cette fonction dessine une porte fenêtre de largeur 30 px avec un balcon.
    :param x: (float) un nombre réel.
    :param y: (float) un nombre réel.
    '''
    # Porte-fenêtre
    up()
    goto(x, y)
    down()
    # si l'heure sélectionné correspons à la nuit, certaines fenêtres sont allumées
    if skyColors == nightSky:
        # Seules 1/5 fenêtres sont allumées, pour des raisons expliquées lors de la présentation orale du projet
        colors = choice(["#f7cb05", "#000929", "#000929", "#000929",
                         "#000929"])
        fillcolor(colors)
    else:
        fillcolor("#5baaf0")
    begin_fill()
    for i in range(2):
        forward(30)
        right(90)
        forward(50)
        right(90)
    end_fill()
    up()

    # Balcon
    width(3)
    right(90)
    forward(25)
    right(90)
    forward(5)
    right(180)
    down()
    for i in range(2):
        forward(40)
        right(90)
        forward(25)
        right(90)

    for i in range(3):
        forward(5)
        right(90)
        forward(25)
        left(90)
        forward(5)
        left(90)
        forward(25)
        right(90)
    forward(5)
    right(90)
    forward(25)
    left(90)
    width(1)
    up()


# Toit triangulaire:

def toit1(season):
    '''
    Cette fonction dessine un toit triangulaire à un niveau donné.
    :param x: (float) un nombre réel.
    :param y_sol: (float) un nombre réel.
    :param niveau: (int) un nombre entier naturel.
    '''
    up()
    forward(70)
    down()
    if season == 0:
        fillcolor('white')
    else:
        fillcolor('black')
    begin_fill()
    forward(80)
    left(153.44)  # Arc tangente de 40/80
    forward(math.sqrt(40 ** 2 + 80 ** 2))  # On cherche la longueur du côté avec le théorème de Pythagore.
    left(53.12)  # Le triangle est isocèle donc l'angle doit faire 126,88°
    forward(math.sqrt(40 ** 2 + 80 ** 2))
    left(153.44)
    forward(80)
    end_fill()
    up()


# Toit triangulaire avec cheminé:

def toit2(season):
    '''
    Cette fonction dessin un toit avec une cheminée à un niveau donné.
    :param x: (float) un nombre réel.
    :param y_sol: (float) un nombre réel.
    :param niveau: (int) un nombre entier naturel.
    '''
    # Toit
    up()
    forward(70)
    down()
    if season == 0:
        fillcolor('white')
    else:
        fillcolor('black')
    begin_fill()
    forward(80)
    left(153.44)
    forward(math.sqrt((40 ** 2 + 80 ** 2) / 2))
    left(26.56)  # Les angles correspondants ont la même mesure.
    forward(45.5)
    left(26.56)
    forward(math.sqrt((40 ** 2 + 80 ** 2) / 2))
    left(153.44)
    forward(80)
    end_fill()

    # Cheminée
    forward(50)
    if season == 0:
        fillcolor('white')
    else:
        fillcolor('black')
    begin_fill()
    left(90)
    forward(30)
    right(90)
    width(2)
    forward(5)
    left(180)
    forward(25)
    right(180)
    forward(5)
    width(1)
    right(90)
    forward(30)
    end_fill()
    left(90)
    up()


# Toit plat:

def toit3(season):
    '''
    Cette fonction dessine un toit plat à un niveau donné.
    :param x: (float) un nombre réel.
    :param y_sol: (float) un nombre réel.
    :param niveau: (int) un nombre entier naturel.
    '''
    up()
    if season == 0:
        color('white')
    else:
        color('black')
    width(10)
    forward(-5)
    down()
    forward(150)
    width(1)
    up()
    color('black')


# Tois aléatoires:

def toit(x, y_sol, niveau, season):
    '''
    Cette fonction génère un toit aléatoire à un niveau donné.
    :param x: (float) un nombre réel.
    :param y_sol: (float) un nombre réel.
    :param niveau: (int) un nombre entier naturel.
    '''
    up()
    # Détermine le niveau où le toit sera dessiné.
    y = y_sol + 60 * niveau
    goto(x, y)
    a = randint(0, 2)
    if a == 0:
        toit1(season)
    elif a == 1:
        toit2(season)
    else:
        toit3(season)


# Façade:

def facade(x, y_sol, couleur, niveau):
    '''
    Cette fonction dessine une façade d'une couleur aléatoire de largeur 140 px et de hauteur 60 px à un niveau donné.
    :param x: (float) un nombre réel.
    :param y_sol: (float) un nombre réel.
    :param couleur: (tuple ou str)
    :param niveau: (int) un nombre entier naturel.
    '''
    up()
    # Détermine le niveau où la façade sera dessinée.
    y = y_sol + 60 * niveau
    goto(x, y)
    down()
    fillcolor(couleur)
    begin_fill()
    forward(140)
    left(90)
    forward(60)
    left(90)
    forward(140)
    left(90)
    forward(60)
    left(90)
    end_fill()


# Rez-de-chaussée;

def rdc(x, y_sol, couleur, skyColors):
    '''
    Cette fonction dessine un rez-de_chaussée (1 porte et 2 fenêtres) au niveau 0.
    :param x: (float) un nombre réel.
    :param y_sol: (float) un nombre réel.
    :param couleur: (tuple ou str)
    '''
    facade(x, y_sol, couleur, 0)
    # Valeur aléatoire de l'abscisse de la porte.
    xPorte = randint(0, 2)
    for i in range(3):
        x += 10
        if xPorte == i:
            porte(x, y_sol)
        else:
            fenetre(x, y_sol + 20, skyColors)
        x += 35


# Etage:

def etage(x, y_sol, couleur, niveau, skyColors):
    '''
    Cette fonction dessine un étage (porte(s)-fenêtre(s) et/ou fenêtre(s)) à un niveau donné.
    :param x: (float) un nombre réel.
    :param y_sol: (float) un nombre réel.
    :param couleur: (tuple ou str)
    :param niveau: (int) un nombre entier naturel.
    '''
    # Un étage n'est pas au niveau du rez-de-chaussée (niveau 0).
    assert niveau != 0

    facade(x, y_sol, couleur, niveau)
    a = randint(1, 2)
    if a == 1:
        fenetre(x + 10, y_sol + 60 * niveau + 15, skyColors)
    else:
        porte_fenetre(x + 10, y_sol + 60 * niveau + 50, skyColors)

    a = randint(1, 2)
    if a == 1:
        fenetre(x + 55, y_sol + 60 * niveau + 15, skyColors)
    else:
        porte_fenetre(x + 55, y_sol + 60 * niveau + 50, skyColors)

    a = randint(1, 2)
    if a == 1:
        fenetre(x + 100, y_sol + 60 * niveau + 15, skyColors)
    else:
        porte_fenetre(x + 100, y_sol + 60 * niveau + 50, skyColors)


# Immeuble:

def immeuble(x, y_sol, season, skyColors):
    '''
    Cette fonction dessine un immeuble (1 rez-de-chaussée avec ou sans 1 à 4 étage(s)).
    :param x: (float) un nombre réel.
    :param y_sol: (float) un nombre réel.
    '''
    # Détermine le nombre d'étage de l'immeuble.
    nbEtage = randint(1, 5)
    # Détermine la couleur de toute la façade de l'immeuble.
    c_facade = couleur()
    rdc(x, y_sol, c_facade, skyColors)
    for i in range(1, nbEtage):
        etage(x, y_sol, c_facade, i, skyColors)
    toit(x, y_sol, nbEtage, season)


def fullRectangle2(widht, height, angle):
    '''
    Ces rectangles peuvent avoir des angles différents (ce qui fait que ce ne sont plus vraiment des rectangles, en fin de compte...)
    Cela permet de créer un effet de perspective, utilisé pour dessiner les traits de la route
    '''
    angle2 = 90 - angle

    begin_fill()
    setheading(0)

    forward(widht)
    right(angle)
    forward(height)
    right(90 + angle2)
    forward(widht)
    right(angle)
    forward(height)
    right(90 + angle2)

    end_fill()


# Création de la route

def route(y_sol):
    '''
    Cette fonction dessine la route
    '''
    setpos((-1022, y_sol - 1))
    fillcolor('#C1BCB9')
    setheading(90)
    fullRectangle(2044, 40)
    setpos((-1022, y_sol - 40))
    fillcolor('#ADA096')
    setheading(90)
    fullRectangle(2044, 5)
    setpos((-1022, y_sol - 45))
    fillcolor('#5C5C5C')
    setheading(90)
    fullRectangle(2044, 100)
    setpos((-1022, y_sol - 145))
    fillcolor('#C1BCB9')
    setheading(90)
    fullRectangle(2044, 45)


# Création des traits de signalisation
def traits(y_sol):
    '''
    Cette fonction dessine les traits de signalisation sur la route
    '''
    x = -1030
    fillcolor('#FFFFFF')
    angle = 150

    for loop in range(30):
        setpos((x, y_sol - 92))
        fullRectangle2(30, 4, angle)
        x += 70
        angle -= 4


# Création du jardin au premier plan

def jardin(y_sol, season, skyColors):
    """
    Fonction qui permet d'adapter la couleur de l'herbe non seulement aux saisons, mais aussi aux cycles jour/nuit
    """

    setpos((-1022, y_sol - 190))
    if skyColors == nightSky:
        if season == 0:
            fillcolor("#c2c0c0")
        elif season == 1:
            fillcolor("#9e4ca6")
        elif season == 3:
            fillcolor("#997225")
        else:
            fillcolor('#01571c')
    else:
        if season == 0:
            fillcolor("#f5f5f5")
        elif season == 1:
            fillcolor("#f79eff")
        elif season == 3:
            fillcolor("#ffbb33")
        else:
            fillcolor('#00ad37')
    setheading(90)
    fullRectangle(2044, 200)


def environnement(y_sol, season, skyColors):
    '''
    Permet de regrouper toutes les fonctions pour création l'environnement
    '''
    up()
    route(y_sol)
    traits(y_sol)
    sol(y_sol - 190)
    jardin(y_sol, season, skyColors)


coef_nuage = 1  # Création et utilisation d'une variable globale coef_nuage pour pouvoir l'utiliser avec la fonction
# eval() dans la fonction nuage()


def nuage():
    '''
    Cette fonction dessine un nuage de taille aléatoire
    '''
    begin_fill()
    global coef_nuage
    coef_nuage = randint(1, 3)  # Détermine la taille du nuage
    forward(coef_nuage * 2 * 2 * 25)  # Dessine le bas du nuage
    liste_mouvement = ["circle(coef_nuage*2*10,180)", "right(90)", "circle(coef_nuage*10,120)", "right(120)",
                       "circle(coef_nuage*10,120)", "right(120)", "circle(coef_nuage*2*10,90)"]
    action = [eval(i) for i in liste_mouvement]
    action = [eval(i) for i in liste_mouvement[::-1]]
    # Les trois lignes précédentes créer une liste de fonction sous forme de str qui sera parcourue par avec la fonction eval() qui va les interpréter comme des listes de fonctions
    end_fill()


def faire_nuages(nb, couleur='white'):
    '''
    Fonction qui permet de dessiner des nuages
    '''
    if data['weather'][0]['main'] == 'Clear':
        return None
    fillcolor(couleur)
    for i in range(nb):
        x, y = randint(-700, 650), randint(210, 300)
        up()
        goto(x, y)
        down()
        begin_fill()
        nuage()
        end_fill()


def pluie(coef=1, vent=False):
    '''
    Fonction qui permet de dessiner la pluie
    '''
    color("blue")
    direction = heading()
    for i in range(50 * (7 - coef)):
        up()
        x, y = randint(-675, 675), randint(-350, 350)
        if vent:
            setheading(270 - data['wind']['speed'])
        else:
            setheading(270)
        goto(x, y)
        down()
        forward(15 - (y / 100))
    color("black")
    setheading(direction)


def temperature():
    '''
    Fonction qui permet d'afficher la température sur l'écran
    '''
    degre = data['main']['temp']
    if degre < 0:
        couleur_degre = (0, 0, 255)
    elif degre < 10:
        couleur_degre = (64, 224, 224)
    elif degre < 20:
        couleur_degre = (64, 64, 64)
    elif degre < 30:
        couleur_degre = (224, 64, 64)
    else:
        couleur_degre = (255, 0, 0)
    up()
    goto(600, -390)
    down()
    color(couleur_degre)
    write(str(degre) + "°", move=False, align='left', font=('Dejavu Sans', 30, 'normal'))
    color('black')


def changement(temps):
    '''
    Fonction qui permet aux devs de modifier manuellement des données pour voir de nouvelles météos
    '''
    data["weather"][0]["description"] = temps


def ciel_bo_ou_pas():
    """
    Renvoie True s'il ne fait pas trs beau dehors et False s'il fait assez beau
    """
    resultat = False
    meteo_ciel_pas_bo = "pluie", "rain", "neige", "snow", "storm"
    for i in meteo_ciel_pas_bo:
        if i in data["weather"][0]["description"]:
            resultat = True
    return resultat


def vent():
    '''
    Fonction qui permet de dessiner le vent
    '''
    v = data['wind']['speed']
    for i in range(int(v)):
        color('black')
        up()
        goto(randint(-700, 650), randint(-350, 300))
        down()
        circle(v * 2 ** 8 / 10, 15)
        circle(v * 2 ** 7 / 10, 30)
        circle(v * 2 ** 6 / 10, 45)
        circle(v * 2 ** 5 / 10, 45)
        circle(v * 2 ** 4 / 10, 90)
        circle(v * 2 ** 5 / 10, 45)
        circle(v * 2 ** 6 / 10, 45)
        circle(v * 2 ** 7 / 10, 30)
        circle(v * 2 ** 8 / 10, 15)

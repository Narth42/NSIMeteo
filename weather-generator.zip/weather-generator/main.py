# Ce fichier fait partie du projet "NSImétéo" et est distribué sous la licence GPL v3+.
# Veuillez consulter le fichier LICENSE pour plus d'informations sur la licence.
# Le projet "NSImétéo" est aussi distribué sous la licence Creative Commons Attribution-ShareAlike (CC BY-SA).
# Pour plus d'informations sur cette licence, veuillez consulter le lien suivant : https://creativecommons.org/licenses/by-sa/4.0/.

from modules import *
from turtle import *


def main():
    '''
    Cette fonction génère un dessin d'un paysage de rue aléatoire.
    '''
    speed(0)    # On définit la vitesse au maximum
    y_sol = -154  # On définit l'ordonné du sol.
    penup()     # On lève le crayon
    ht()       # On cache la tortue
    setup(1500, 750) # On définit la taille de la fenêtre

    # On génère la graine, et à partir de ça tous les facteurs qui définiront l'environnement
    season = getSeason()
    hour = getHour()
    minute = getMinute()
    if not ciel_bo_ou_pas(): skyColors = partDay(hour, season)
    else: skyColors = rainySky

    # On assigne un nom aux saisons et aux mois pour que ça soit plus clair pour l'utilisateur
    monthsList = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"]
    # Rédaction de la présentation de la graine à l'utilisateur
    presentation = ville.capitalize() + ", le " + str(ajd_dico["jour"]) + " " + monthsList[ajd_dico["mois"]-1] + " " + str(ajd_dico["annee"])
    # Affichage de la présentation de la graine à l'utilisateur
    title(presentation) # avec le nom de la fenêtre
    print(presentation) # dans le terminal

    # Création du ciel et du Soleil (ou de la Lune) en fonction des paramètres définis plus haut
    createSky(skyColors)
    createSun(hour, minute, season)

    # Création du sol :
    sol(y_sol)

    # Création des 4 immeubles :
    for i in range(4):
        immeuble(-370+i*200, y_sol, season, skyColors)

    # Enfin, création de l'environnement :
    environnement(y_sol, season, skyColors)
    vent()
    if ciel_bo_ou_pas():
        pluie(randint(1, 3), True)
        faire_nuages(randint(10, 15), 'dark grey')
    else:
        faire_nuages(randint(0, 7))


# On exécute la fonction "main" et on active le "exitonclick"
main()
temperature()
exitonclick()